import os
from typing import Union

import pandas as pd

from .trainer import Trainer


def training_with_none_ff_and_regression_models(
    features: pd.DataFrame,
    labels: pd.Series,
    output_path: str = None,
    train_type: str = "general",
    is_use_model_param: bool = False
):
    output_path = os.path.join(output_path, 'none_ff_and_regression_models')
    trainer = Trainer(train_type)
    trainer.set_is_use_model_params(is_use_model_param)
    return trainer.run(features, labels, output_path=output_path)


def training_with_none_ff_and_classification_models(
    features: pd.DataFrame,
    labels: pd.Series,
    output_path: str = None,
    train_type: str = "general",
    is_use_model_param: bool = False
):
    output_path = os.path.join(output_path, 'none_ff_and_classification_models')
    trainer = Trainer(train_type)
    trainer.set_model_tags("classification")
    trainer.set_is_use_model_params(is_use_model_param)
    return trainer.run(features, labels, output_path=output_path)


def training_with_all_ffs_and_regression_models(
    features: pd.DataFrame,
    labels: pd.Series,
    output_path: str = None,
    train_type: str = "general"
):
    output_path = os.path.join(output_path, 'all_ffs_and_regression_models')
    trainer = Trainer(train_type)
    trainer.set_ff_tags("all_ff")
    return trainer.run(features, labels, output_path=output_path)


def training_with_all_ffs_and_classification_models(
    features: pd.DataFrame,
    labels: pd.Series,
    output_path: str = None,
    train_type: str = "general"
):
    output_path = os.path.join(output_path, 'all_ffs_and_classification_models')
    trainer = Trainer(train_type)
    trainer.set_base_config(
        ff_tags="all_ff",
        model_tags="classification"
    )
    return trainer.run(features, labels, output_path=output_path)


def training_with_custom_ffs_and_models(
    features: pd.DataFrame,
    labels: pd.Series,
    output_path: str = None,
    ff_tags: Union[None, str, list] = None,
    model_tags: Union[str, list] = "regression",
    train_type: str = "general",
    **kwargs
):
    output_path = os.path.join(output_path, 'custom_ffs_and_models')
    trainer = Trainer(train_type)
    trainer.set_base_config(
        ff_tags=ff_tags,
        model_tags=model_tags,
        **kwargs
    )
    return trainer.run(features, labels, output_path=output_path)


