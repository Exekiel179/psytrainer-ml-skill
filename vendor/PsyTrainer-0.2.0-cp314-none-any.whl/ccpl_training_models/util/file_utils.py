#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/06/10
@Version: 1.0.0
@Description: 文件处理相关函数
'''

from simplejson import dumps, loads


def to_jsonfile(data, json_path):
    json_data = dumps(data)
    with open(json_path, "w") as fp:
        fp.write(json_data)


def from_jsonfile(json_path):
    with open(json_path, "r") as fp:
        data = str(fp.read())
        json_data = loads(data)
    return json_data
