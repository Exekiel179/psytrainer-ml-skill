#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 获取网格搜索的最佳得分和对应参数
'''


def get_grid_best_params(grid, cross_validation_times, scoring, refit):
    best_params_info = {'best_score': grid.best_score_, 'best_params': str(grid.best_params_)}
    cv_result = grid.cv_results_
    best_index = grid.best_index_
    best_score_splits = []
    for i in range(cross_validation_times):
        split_label = 'split%d_test_%s' % (i, refit)
        best_score_splits.append(cv_result[split_label][best_index])
    best_params_info['best_score_splits'] = best_score_splits

    for key in scoring.keys():
        if key == refit:
            continue
        mean_scoring_label = 'mean_test_%s' % key
        best_params_info['%s_mean_score' % key] = cv_result[mean_scoring_label][best_index]
        score_splits = []
        for i in range(cross_validation_times):
            split_label = 'split%d_test_%s' % (i, key)
            score_splits.append(cv_result[split_label][best_index])
        best_params_info['%s_score_splits' % key] = score_splits

    return best_params_info
