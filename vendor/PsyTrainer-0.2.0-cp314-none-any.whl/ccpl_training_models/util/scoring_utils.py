#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 各种得分评定标准，需要注意通过网格搜索GridSearchCV()获得的得分，
              当greater_is_better = False时，得分为负值（表示该得分是越小越好的意思），
              greater_is_better = True时，等分为正值。
'''

from enum import Enum
import numpy as np
from scipy import stats
from sklearn.metrics import make_scorer, mean_absolute_error, mean_squared_error, r2_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, confusion_matrix


def pearson_r(y_true, y_predict):
    score = stats.pearsonr(y_true, y_predict)[0]
    # 如何有一列数值为一样的数值，则score会返回nan
    if np.isnan(score):
        score = 0
    print('-----pearson_r score:', score)
    return score


def pearson_r_scorer():
    return make_scorer(pearson_r, greater_is_better=True)


def pearson_p(y_true, y_predict):
    score = stats.pearsonr(y_true, y_predict)[1]
    # 如何有一列数值为一样的数值，则score会返回nan
    if np.isnan(score):
        score = 1
    print('-----pearson_p score:', score)
    return score


def pearson_p_scorer():
    return make_scorer(pearson_p, greater_is_better=False)


def mae_scoring(y_true, y_predict):
    score = mean_absolute_error(y_true, y_predict)
    print('-----mae score:', score)
    return score


def mae_scorer():
    return make_scorer(mae_scoring, greater_is_better=False)


def mse_scoring(y_true, y_predict):
    score = mean_squared_error(y_true, y_predict)
    print('-----mse score:', score)
    return score


def mse_scorer():
    return make_scorer(mse_scoring, greater_is_better=False)


def rmse_scoring(y_true, y_predict):
    mse = mean_squared_error(y_true, y_predict)
    score = np.sqrt(mse)
    print('-----rmse score:', score)
    return score


def rmse_scorer():
    return make_scorer(rmse_scoring, greater_is_better=False)


def r2_scoring(y_true, y_predict):
    score = r2_score(y_true, y_predict)
    print('-----r2 score:', score)
    return score


def r2_scorer():
    return make_scorer(r2_scoring, greater_is_better=False)


def accuracy_scoring(y_true, y_predict):
    score = accuracy_score(y_true, y_predict)
    print('-----accuracy score:', score)
    return score


def accuracy_scorer():
    return make_scorer(accuracy_scoring, greater_is_better=True)


def precision_scoring(y_true, y_predict):
    score = precision_score(y_true, y_predict)
    print('-----precision score:', score)
    return score


def precision_scorer():
    return make_scorer(precision_scoring, greater_is_better=True)


def recall_scoring(y_true, y_predict):
    score = recall_score(y_true, y_predict)
    print('-----recall score:', score)
    return score


def recall_scorer():
    return make_scorer(recall_scoring, greater_is_better=True)


def f1_scoring(y_true, y_predict):
    score = f1_score(y_true, y_predict)
    print('-----f1 score:', score)
    return score


def f1_scorer():
    return make_scorer(f1_scoring, greater_is_better=True)


def auc_scoring(y_true, y_predict):
    fpr, tpr, thresholds = roc_curve(y_true, y_predict)
    score = auc(fpr, tpr)
    print('-----auc score:', score)
    return score


def auc_scorer():
    return make_scorer(auc_scoring, greater_is_better=True)


class SCORING(Enum):
    pearson_r = pearson_r_scorer()
    pearson_p = pearson_p_scorer()
    mae = mae_scorer()
    mse = mse_scorer()
    rmse = rmse_scorer()
    r2 = r2_scorer()
    accuracy = accuracy_scorer()
    precision = precision_scorer()
    recall = recall_scorer()
    f1 = f1_scorer()
    auc = auc_scorer()


SCORINGS_DEFAULT = [SCORING.pearson_r, SCORING.mae, SCORING.mse, SCORING.rmse, SCORING.r2]
SCORINGS_CLASSIFIER = [SCORING.f1, SCORING.accuracy, SCORING.precision, SCORING.recall, SCORING.auc]
