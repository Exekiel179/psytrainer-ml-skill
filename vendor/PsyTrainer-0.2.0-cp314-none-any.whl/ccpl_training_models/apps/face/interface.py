#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 定义面向面部视频分析场景下训练接口
'''


import numpy as np

from model.model_training import ModelTraining
from params.train.face.default import CatBoostParams, LGBMParams, RandomForestParams, SVRParams, XGBoostParams
from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT


def face_training_by_pca_and_randomforestregressor(X, Y, pca_num = 30, cv_times = 5, scorings = SCORINGS_DEFAULT, output_path: str = None):
    model_training = ModelTraining('FFByPca', 
                                   {'pca_num': pca_num}, 
                                   'ModelRandomForestRegressor', 
                                   {'training_params': RandomForestParams.regression.value},
                                   cv_times,
                                   scorings,
                                   output_path = output_path)
    return model_training.run(X, Y)

def face_training_by_randomforestregressor(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining(None, 
                                   None, 
                                   'ModelRandomForestRegressor', 
                                   {'training_params': RandomForestParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)
    
def face_training_by_pca_and_catboostregressor(X, Y, pca_num = 30, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca', 
                                   {'pca_num': pca_num}, 
                                   'ModelCatBoostRegressor', 
                                   {'training_params': CatBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_catboostregressor(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining(None, 
                                   None, 
                                   'ModelCatBoostRegressor', 
                                   {'training_params': CatBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_pca_and_svr(X, Y, pca_num = 30, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca', 
                                   {'pca_num': pca_num}, 
                                   'ModelSVRRegressor', 
                                   {'training_params': SVRParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_pca_and_svr(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining(None, 
                                   None, 
                                   'ModelSVRRegressor', 
                                   {'training_params': SVRParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_pca_and_xgboost(X, Y, pca_num = 30, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca', 
                                   {'pca_num': pca_num}, 
                                   'ModelXGBoostRegressor', 
                                   {'training_params': XGBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_pca_and_xgboost(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining(None, 
                                   None, 
                                   'ModelXGBoostRegressor', 
                                   {'training_params': XGBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)
    
def face_training_by_pca_and_lgbm(X, Y, pca_num = 30, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca', 
                                   {'pca_num': pca_num}, 
                                   'ModelLGBMRegressor', 
                                   {'training_params': LGBMParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def face_training_by_lgbm(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT):
    model_training = ModelTraining(None, 
                                   None, 
                                   'ModelLGBMRegressor', 
                                   {'training_params': LGBMParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)