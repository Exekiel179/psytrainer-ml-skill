#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/06/1
@Version: 1.0.0
@Description: 定义模型训练接口
'''

import os
import shutil
import numpy as np
import pandas as pd
from ccpl_training_models.feature.ff_factory import FFFactory
from ccpl_training_models.model.model_factory import ModelFactory
from ccpl_training_models.model.model_training import ModelTraining
from ccpl_training_models.util.file_utils import from_jsonfile, to_jsonfile
from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT


def training_with_ff_and_model(X: pd.DataFrame, Y: pd.Series, feature_filter_tag: str, feature_filter_params: dict,
                               model_tag: str, model_params: dict, cv_times: int, scorings=SCORINGS_DEFAULT,
                               output_path: str = None):
    model_training = ModelTraining(feature_filter_tag,
                                   feature_filter_params,
                                   model_tag,
                                   model_params,
                                   cv_times,
                                   scorings,
                                   output_path=output_path)
    return model_training.run(X, Y)


def training_with_all_ffs_and_regression_models(X: pd.DataFrame, Y: pd.Series, cv_times: int, scorings=SCORINGS_DEFAULT,
                                                pca_num=30, output_path: str = None, is_need_clean: bool = False):
    '''
    函数拥有中断后，下次接着运行的功能。
    
    如果需要重新运行可以手动删除输出文件夹内的内容，
    或者第一次运行将is_need_clean设置为True，如果后续中断了切记把is_need_clean设置为False。
    
    '''
    print('training_with_all_ffs_and_regression_models...')
    if not output_path:
        raise Exception('output error: please input a output path.')
    output_path = os.path.join(output_path, 'all_ff_and_regression_model/')

    if is_need_clean:
        # 清除之前的运行记录
        if os.path.isdir(output_path):
            shutil.rmtree(output_path)

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    default_params = dict(
        cv=cv_times,
        scorings=scorings,
        pca_num=pca_num,
        threshold=0.0,
        estimator=None,
        eval_metric='neg_root_mean_squared_error',
        greater_is_better=True,
        label=Y
    )
    print(default_params, '-----------:', default_params['scorings'], '-----------:', default_params['pca_num'])

    ff_tags = FFFactory.get_all_ff_tags()
    model_factory = ModelFactory()
    model_tags = model_factory.get_all_model_tags(model_type=1)

    sample_num = X.shape[1]
    n = np.min([default_params['pca_num'], sample_num])
    default_params['pca_num'] = n

    result_list = []
    best_result = None

    best_result_path = os.path.join(output_path, 'best_result.json')
    result_list_path = os.path.join(output_path, 'result_list.json')
    if os.path.exists(best_result_path):
        result_list = from_jsonfile(result_list_path)
    if os.path.exists(result_list_path):
        best_result = from_jsonfile(best_result_path)
    print('from_jsonfile best_result:', best_result)
    print('from_jsonfile result_list:', result_list)
    # 正在运行的tag
    running_tags = []
    # 运行中断保存在文件中运行过的tag
    done_tags = []
    done_file_path = os.path.join(output_path, 'done_tag.csv')
    if os.path.exists(done_file_path):
        done_tags = list(pd.read_csv(done_file_path).loc[:, 'tag'])
    print('done_tags: ', done_tags)

    for ff_tag in ff_tags:
        for model_tag in model_tags:
            # 是否中断后，继续训练
            tag = '%s#%s' % (ff_tag, model_tag)
            if tag in done_tags:
                # 判断tag是否已经存在，存在就不在训练，继续下一次训练
                running_tags.append(tag)
                continue

            model_training = ModelTraining(ff_tag,
                                           default_params,
                                           model_tag,
                                           {'training_params': model_factory.get_model_params(model_tag)},
                                           cv_times,
                                           scorings,
                                           output_path=output_path)
            result, _, _ = model_training.run(X, Y)
            result['tag'] = tag
            result_list.append(result)
            if result_list is not None and type(result_list) is list and len(result_list) > 0:
                print('result sort running...')
                result_list.sort(key=lambda x: x['best_score'], reverse=True)
                best_result = result_list[0].copy()

            running_tags.append(tag)
            # 保存运行状态
            if running_tags is not None and len(running_tags) > 0:
                tags_data = pd.DataFrame(running_tags, columns=['tag'])
                tags_data.to_csv(done_file_path)

            to_jsonfile(best_result, best_result_path)
            to_jsonfile(result_list, result_list_path)

    return best_result, result_list


def training_with_default_params_of_regression_models(X: pd.DataFrame, Y: pd.Series, feature_filter_tag: str,
                                                      feature_filter_params: dict,
                                                      cv_times: int, scorings=SCORINGS_DEFAULT,
                                                      output_path: str = None, is_use_model_param=False,
                                                      is_need_clean: bool = False):
    '''
    函数拥有中断后，下次接着运行的功能。
    
    如果需要重新运行可以手动删除输出文件夹内的内容，
    或者第一次运行将is_need_clean设置为True，如果后续中断了切记把is_need_clean设置为False。
    
    '''
    print('training_with_default_params_of_regression_models...')
    if not output_path:
        raise Exception('output error: please input a output path.')
    output_path = os.path.join(output_path, 'all_regression_models_with_default_params/')

    if is_need_clean:
        # 清除之前的运行记录
        if os.path.isdir(output_path):
            shutil.rmtree(output_path)

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    model_factory = ModelFactory()
    model_tags = model_factory.get_all_model_tags(model_type=1)

    result_list = []
    best_result = None

    best_result_path = os.path.join(output_path, 'best_result.json')
    result_list_path = os.path.join(output_path, 'result_list.json')
    if os.path.exists(best_result_path):
        result_list = from_jsonfile(result_list_path)
    if os.path.exists(result_list_path):
        best_result = from_jsonfile(best_result_path)
    print('from_jsonfile best_result:', best_result)
    print('from_jsonfile result_list:', result_list)
    # 正在运行的tag
    running_tags = []
    # 运行中断保存在文件中运行过的tag
    done_tags = []
    done_file_path = os.path.join(output_path, 'done_tag.csv')
    if os.path.exists(done_file_path):
        done_tags = list(pd.read_csv(done_file_path).loc[:, 'tag'])
    print('done_tags: ', done_tags)

    for model_tag in model_tags:
        # 是否中断后，继续训练
        tag = '%s#%s' % (feature_filter_tag, model_tag)
        if tag in done_tags:
            # 判断tag是否已经存在，存在就不在训练，继续下一次训练
            running_tags.append(tag)
            continue

        model_training = ModelTraining(feature_filter_tag,
                                       feature_filter_params,
                                       model_tag,
                                       {'training_params': model_factory.get_model_params(model_tag) if is_use_model_param else None},
                                       cv_times,
                                       scorings,
                                       output_path=output_path)
        result, _, _ = model_training.run(X, Y)
        result['tag'] = tag
        result_list.append(result)
        if result_list is not None and type(result_list) is list and len(result_list) > 0:
            print('result sort running...')
            result_list.sort(key=lambda x: x['best_score'], reverse=True)
            best_result = result_list[0].copy()

        running_tags.append(tag)
        # 保存运行状态
        if running_tags is not None and len(running_tags) > 0:
            tags_data = pd.DataFrame(running_tags, columns=['tag'])
            tags_data.to_csv(done_file_path)

        to_jsonfile(best_result, best_result_path)
        to_jsonfile(result_list, result_list_path)

    return best_result, result_list


def training_with_all_ffs_and_classification_models(X: pd.DataFrame, Y: pd.Series, cv_times: int,
                                                    scorings=SCORINGS_DEFAULT,
                                                    pca_num=30, output_path: str = None, is_need_clean: bool = False):
    '''
    函数拥有中断后，下次接着运行的功能。
    
    如果需要重新运行可以手动删除输出文件夹内的内容，
    或者第一次运行将is_need_clean设置为True，如果后续中断了切记把is_need_clean设置为False。
    
    '''
    print('training_with_all_ffs_and_classification_models...')
    if not output_path:
        raise Exception('output error: please input a output path.')
    output_path = os.path.join(output_path, 'all_ff_and_classification_model/')

    if is_need_clean:
        # 清除之前的运行记录
        if os.path.isdir(output_path):
            shutil.rmtree(output_path)

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    default_params = dict(
        cv=cv_times,
        scorings=scorings,
        pca_num=pca_num,
        threshold=0.0,
        estimator=None,
        eval_metric='neg_root_mean_squared_error',
        greater_is_better=True,
        label=Y
    )
    print(default_params, '-----------:', default_params['scorings'], '-----------:', default_params['pca_num'])

    ff_tags = FFFactory.get_all_ff_tags()
    model_factory = ModelFactory()
    model_tags = model_factory.get_all_model_tags(model_type=0)

    sample_num = X.shape[1]
    n = np.min([default_params['pca_num'], sample_num])
    default_params['pca_num'] = n

    result_list = []
    best_result = None

    best_result_path = os.path.join(output_path, 'best_result.json')
    result_list_path = os.path.join(output_path, 'result_list.json')
    if os.path.exists(best_result_path):
        result_list = from_jsonfile(result_list_path)
    if os.path.exists(result_list_path):
        best_result = from_jsonfile(best_result_path)
    print('from_jsonfile best_result:', best_result)
    print('from_jsonfile result_list:', result_list)
    # 正在运行的tag
    running_tags = []
    # 运行中断保存在文件中运行过的tag
    done_tags = []
    done_file_path = os.path.join(output_path, 'done_tag.csv')
    if os.path.exists(done_file_path):
        done_tags = list(pd.read_csv(done_file_path).loc[:, 'tag'])
    print('done_tags: ', done_tags)
    
    for ff_tag in ff_tags:
        for model_tag in model_tags:
            # 是否中断后，继续训练
            tag = '%s#%s' % (ff_tag, model_tag)
            if tag in done_tags:
                # 判断tag是否已经存在，存在就不再训练，继续下一次训练
                running_tags.append(tag)
                continue

            model_training = ModelTraining(ff_tag,
                                           default_params,
                                           model_tag,
                                           {'training_params': model_factory.get_model_params(model_tag)},
                                           cv_times,
                                           scorings,
                                           output_path=output_path)
            result, _, _ = model_training.run(X, Y)
            result['tag'] = tag
            result_list.append(result)
            if result_list is not None and type(result_list) is list and len(result_list) > 0:
                print('result sort running...')
                result_list.sort(key=lambda x: x['best_score'], reverse=True)
                best_result = result_list[0].copy()

            running_tags.append(tag)
            # 保存运行状态
            if running_tags is not None and len(running_tags) > 0:
                tags_data = pd.DataFrame(running_tags, columns=['tag'])
                tags_data.to_csv(done_file_path)

            to_jsonfile(best_result, best_result_path)
            to_jsonfile(result_list, result_list_path)

    return best_result, result_list


def training_with_default_params_of_classification_models(X: pd.DataFrame, Y: pd.Series, feature_filter_tag: str,
                                                          feature_filter_params: dict,
                                                          cv_times: int, scorings=SCORINGS_DEFAULT,
                                                          output_path: str = None, is_use_model_param=False,
                                                          is_need_clean: bool = False):
    '''
    函数拥有中断后，下次接着运行的功能。
    
    如果需要重新运行可以手动删除输出文件夹内的内容，
    或者第一次运行将is_need_clean设置为True，如果后续中断了切记把is_need_clean设置为False。
    
    '''
    print('training_with_default_params_of_classification_models...')
    if not output_path:
        raise Exception('output error: please input a output path.')
    output_path = os.path.join(output_path, 'all_classification_models_with_default_params/')

    if is_need_clean:
        # 清除之前的运行记录
        if os.path.isdir(output_path):
            shutil.rmtree(output_path)

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    model_factory = ModelFactory()
    model_tags = model_factory.get_all_model_tags(model_type=0)

    result_list = []
    best_result = None

    best_result_path = os.path.join(output_path, 'best_result.json')
    result_list_path = os.path.join(output_path, 'result_list.json')
    if os.path.exists(best_result_path):
        result_list = from_jsonfile(result_list_path)
    if os.path.exists(result_list_path):
        best_result = from_jsonfile(best_result_path)
    print('from_jsonfile best_result:', best_result)
    print('from_jsonfile result_list:', result_list)
    # 正在运行的tag
    running_tags = []
    # 运行中断保存在文件中运行过的tag
    done_tags = []
    done_file_path = os.path.join(output_path, 'done_tag.csv')
    if os.path.exists(done_file_path):
        done_tags = list(pd.read_csv(done_file_path).loc[:, 'tag'])
    print('done_tags: ', done_tags)

    for model_tag in model_tags:
        # 是否中断后，继续训练
        tag = '%s#%s' % (feature_filter_tag, model_tag)
        if tag in done_tags:
            # 判断tag是否已经存在，存在就不在训练，继续下一次训练
            running_tags.append(tag)
            continue

        model_training = ModelTraining(feature_filter_tag,
                                       feature_filter_params,
                                       model_tag,
                                       {'training_params': model_factory.get_model_params(model_tag) if is_use_model_param else None},
                                       cv_times,
                                       scorings,
                                       output_path=output_path)
        result, _, _ = model_training.run(X, Y)
        result['tag'] = tag
        result_list.append(result)
        if result_list is not None and type(result_list) is list and len(result_list) > 0:
            print('result sort running...')
            result_list.sort(key=lambda x: x['best_score'], reverse=True)
            best_result = result_list[0].copy()

        running_tags.append(tag)
        # 保存运行状态
        if running_tags is not None and len(running_tags) > 0:
            tags_data = pd.DataFrame(running_tags, columns=['tag'])
            tags_data.to_csv(done_file_path)

        to_jsonfile(best_result, best_result_path)
        to_jsonfile(result_list, result_list_path)

    return best_result, result_list
