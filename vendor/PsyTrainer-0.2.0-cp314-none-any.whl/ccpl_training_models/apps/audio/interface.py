#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: LY
@Date: 2023/05/20
@Version: 1.0.0
@Description: 定义面向音频分析场景下训练接口
'''

import numpy as np

from model.model_training import ModelTraining
from params.train.audio.default import KNeighborsRegressorParams, RandomForestParams

from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT


def audio_training_by_freg_and_randomforestregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByFregression',
                                   {'label': Y},
                                   'ModelRandomForestRegressor',
                                   {'training_params': RandomForestParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def audio_training_by_freg_and_kneighborsregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByFregression',
                                   {'label': Y},
                                   'ModelKNeighborsRegressor',
                                   {'training_params': KNeighborsRegressorParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)
