#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: hn
@Date: 2023/04/20
@Version: 1.0.0
@Description: 定义面向文本分析场景下训练接口
'''

from sklearn.ensemble import RandomForestRegressor

from model.model_training import ModelTraining
from params.train.text.default import BaggingParams, ExtraTreeParams, KNeighborsParams, RandomForestParams
from params.train.text.default import AdaBoostParams
from params.train.text.default import GradientBoostingParams
from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT


def text_training_by_normal_and_extratreeregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByNor',
                                   None,
                                   'ModelExtraTreeRegressor',
                                   {'training_params': ExtraTreeParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)


def text_training_by_extratreeregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining(None,
                                   None,
                                   'ModelExtraTreeRegressor',
                                   {'training_params': ExtraTreeParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def text_training_by_normal_and_adaboostregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByNor',
                                   None,
                                   'ModelAdaBoostRegressor',
                                   {'training_params': AdaBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)


def text_training_by_adaboostregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining(None,
                                   None,
                                   'ModelAdaBoostRegressor',
                                   {'training_params': AdaBoostParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def text_training_by_normal_and_gradientboostingregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByNor',
                                   None,
                                   'ModelGradientBoostingRegressor',
                                   {'training_params': GradientBoostingParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)


def text_training_by_gradientboostingregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining(None,
                                   None,
                                   'ModelGradientBoostingRegressor',
                                   {'training_params': GradientBoostingParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def text_training_by_normal_and_baggingregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByNor',
                                   None,
                                   'ModelBaggingRegressor',
                                   {'training_params': BaggingParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)


def text_training_by_baggingregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining(None,
                                   None,
                                   'ModelBaggingRegressor',
                                   {'training_params': BaggingParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def text_training_by_normal_and_kneighborsregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByNor',
                                   None,
                                   'ModelKNeighborsRegressor',
                                   {'training_params': KNeighborsParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)


def text_training_by_kneighborsregressor(X, Y, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining(None,
                                   None,
                                   'ModelKNeighborsRegressor',
                                   {'training_params': KNeighborsParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)
    
def gamingbehave_training_by_stepforward_and_randomforestregressor(X, Y, cv_times = 5, scorings = SCORINGS_DEFAULT, output_path: str = None):
    model_training = ModelTraining('FFByStepForward',
                                   {'threshold': 0.0, 
                                    'cv': cv_times,
                                    'estimator': RandomForestRegressor(), 
                                    'eval_metric': 'neg_root_mean_squared_error', 
                                    'greater_is_better': True, 
                                    'label': Y},
                                   'ModelRandomForestRegressor', 
                                    {'training_params': RandomForestParams.regression.value},
                                    cv_times,
                                    scorings,
                                    output_path = output_path)
    return model_training.run(X, Y)