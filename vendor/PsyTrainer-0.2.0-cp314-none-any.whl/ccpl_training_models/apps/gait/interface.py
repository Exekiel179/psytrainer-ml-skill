#!/usr/bin/python3
# -*- coding: UTF-8 -*-

'''
@Author: wyy
@Date: 2023/04
@Version: 1.0.0
@Description: 定义面向步态视频分析场景下训练接口
'''

from model.model_training import ModelTraining
from params.train.gait.default import RandomForestParams, SVRParams, GPRParams, LRParams
from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT


def gait_training_by_pca_and_randomforestregressor(X, Y, pca_num=30, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca',
                                   {'pca_num': pca_num},
                                   'ModelRandomForestRegressor',
                                   {'training_params': RandomForestParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)



def gait_training_by_pca_and_svr(X, Y, pca_num=30, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca',
                                   {'pca_num': pca_num},
                                   'ModelSVRRegressor',
                                   {'training_params': SVRParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def gait_training_by_pca_and_gpr(X, Y, pca_num=30, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca',
                                   {'pca_num': pca_num},
                                   'ModelGPRRegressor',
                                   {'training_params': GPRParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)

def gait_training_by_pca_and_lr(X, Y, pca_num=30, cv_times=5, scorings=SCORINGS_DEFAULT):
    model_training = ModelTraining('FFByPca',
                                   {'pca_num': pca_num},
                                   'ModelLRRegressor',
                                   {'training_params': LRParams.regression.value},
                                   cv_times,
                                   scorings)
    return model_training.run(X, Y)









