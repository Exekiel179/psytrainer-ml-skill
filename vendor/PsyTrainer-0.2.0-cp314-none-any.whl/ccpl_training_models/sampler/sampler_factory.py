#!/usr/bin/env python
# -*- coding:utf-8 -*-

from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.combine import SMOTETomek, SMOTEENN
from imblearn.under_sampling import ClusterCentroids, RandomUnderSampler, NearMiss

"""
    Over Sampling:
    1. RandomOverSampler: Random oversampling
    2. SMOTE: SMOTE(synthetic minority oversampling technique)
    
    Combination：
    3. SMOTETomek: 组合抽样，SMOTETomek
    4. SMOTEENN: 组合抽样，SMOTEENN
    
    Under Sampling:
    5. ClusterCentroids: ClusterCentroids, #对多数类样本生成新样本去代替原样本
    6. RandomUnderSampler: RandomUnderSampler, #直接选取随机删除
    7. NearMiss: NearMiss #基于NN启发式算法
"""

SAMPLING_METHODS = {
    "RandomOverSampler": RandomOverSampler(random_state=0, sampling_strategy='auto'),
    "SMOTE": SMOTE(sampling_strategy='auto', random_state=7),
    "SMOTETomek": SMOTETomek(random_state=0),
    "SMOTEENN": SMOTEENN(random_state=0),
    "ClusterCentroids": ClusterCentroids(random_state=0),  # 对多数类样本生成新样本去代替原样本
    "RandomUnderSampler": RandomUnderSampler(random_state=0),  # 直接选取随机删除
    "NearMiss": NearMiss(version=1)  # 基于NN启发式算法
}


class SamplerFactory:

    @staticmethod
    def get_all_sampler_tags():
        return list(SAMPLING_METHODS.keys())

    @staticmethod
    def resample(x, y, resample_tag):
        assert resample_tag in SAMPLING_METHODS.keys(), f"Invalid resample_tag: {resample_tag}"

        x_re, y_re = SAMPLING_METHODS[resample_tag].fit_resample(x, y)
        return x_re, y_re
