#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 特征筛选工厂类，需要将具体的特征筛选实例类注册在这个文件中。如“from feature.reduction.ff_by_pca import FFByPca”
'''

from .reduction.ff_by_pca import FFByPca
from .selection.ff_by_normalization import FFByNor
from .selection.ff_by_stepforward import FFByStepForward
from .selection.ff_by_fregression import FFByFregression


class FFFactory(object):
    FF_PARAMS = {
        'FFByPca': {'pca_num': 30},
        'FFByNor': None,
        'FFByStepForward': {
            'threshold': 0.0,
            'estimator': None,
            'eval_metric': 'neg_root_mean_squared_error',
            'greater_is_better': True,
            'label': None,
            'cv': 5
        },
        'FFByFregression': {'label': None}
    }

    @classmethod
    def get_all_ff_tags(cls):
        return list(cls.FF_PARAMS.keys())

    @classmethod
    def get_ff_params(cls, tag):
        return cls.FF_PARAMS[tag]

    @staticmethod
    def create_ff(name: str, params: dict):
        return eval(name)(params)
