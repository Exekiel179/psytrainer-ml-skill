#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: LY
@Date: 2023/05/20
@Version: 1.0.0
@Description: f_regression 特征选择
'''

import pandas as pd
from sklearn.feature_selection import f_regression

from ..ff_base import FFBase

import os


class FFByFregression(FFBase):
    """
    Feature filter by Pca,

    """
    params = {}
    out_features = None

    def __init__(self, params: dict):
        """
        实例初始化过程，保存传入的参数。

        Args:
            params (dict, optional): 详见父类说明:
            {'label': pandas.Series}
        """

        print(type(self).__name__, ' __init__ params:', params)
        self.set_params(params)

    def set_params(self, params: dict):
        super().set_params(params)

    def feature_filter(self, features: pd.DataFrame):
        """
        标准化特征。具体定义见父类说明。

        Args:
            features (DataFrame, optional): 遵循基类的参数类型.

        Returns:
            DataFrame: 返回值类型，也是类包pandas的DataFrame类型。
        """
        #print('feature_filter: FDRWithNor...')
       # print('params:', self.params)

        # label2 = self.label.get('label').to_frame()
        label = self.params['label']

        ffs = f_regression(features, label)

        variable = []

        for i in range(0, len(features.columns) - 1):
            # 自行设置筛选条件，这里选择F值大于5的变量
            if ffs[0][i] >= 5:
                variable.append(features.columns[i])
        self.out_features = features.loc[:, variable]
        return self.out_features
    
    def save(self, output_path: str = None):
        if not os.path.isdir(output_path):
            os.makedirs(output_path)
            
        if self.out_features is not None:
            feature_output_path = os.path.join(output_path, 'feature_filter.csv')
            ff_data = pd.DataFrame(list(self.out_features), columns=['feature_name'])
            ff_data.to_csv(feature_output_path)
        else:
            raise ValueError('out_features empty error, please assign a value to the class variable out_features in the feature_filter function!')
            
        