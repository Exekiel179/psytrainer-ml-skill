#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: Sihua
@Date: 2023/04/28
@Version: 1.0.0
@Description: 特征筛选工厂类，通过向前步进，结合具体的算法完成特征选择
'''

import os
import shutil
import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_score
from ccpl_training_models.config.project_config import DEBUG, STEPFORWARD_MAX_FEATURE_NUMBER

from ..ff_base import FFBase
from ..reduction.ff_by_pca import FFByPca


class FFByStepForward(FFBase):
    ff_pca = None

    def __init__(self, params):
        print(type(self).__name__, ' __init__ params:', params)
        self.threshold = params['threshold']
        self.estimator = params['estimator']
        self.eval_metric = params['eval_metric']
        self.greater_is_better = params['greater_is_better']
        self.label = params['label']
        self.cv = params['cv']
        self.set_params(params)

    def set_params(self, params: dict):
        super().set_params(params)

    def feature_filter(self, features: pd.DataFrame) -> pd.DataFrame:
        temp_features = features.copy()
        label = self.label
        names_length = temp_features.shape[1]
        if names_length > STEPFORWARD_MAX_FEATURE_NUMBER:
            # 如果特征数量太多，大于 ‘STEPFORWARD_MAX_FEATURE_NUMBER’ 的数量，先做一个PCA的筛选。
            # ‘STEPFORWARD_MAX_FEATURE_NUMBER’ 可以在 ‘source/config/project_config.py’ 中配置。
            self.ff_pca = FFByPca({'pca_num': STEPFORWARD_MAX_FEATURE_NUMBER})
            temp_features = self.ff_pca.feature_filter(temp_features)
        names_length = temp_features.shape[1]
        print('names_length: ', names_length)
        if DEBUG:
            names_length = 6
        features_number = list(range(names_length))

        feature_selected = []
        feature_not_selected = features_number

        score_best = -1e10 if self.greater_is_better else 1e10
        feature_best = None

        for i in range(names_length):
            print('FFByStepForward run 1---total: %d, now i: %d' % (i, names_length))
            update = False
            for feature in feature_not_selected:
                print('FFByStepForward run 2---feature: %d' % feature)
                feature_now = feature_selected + [feature]
                score_now = np.mean(cross_val_score(estimator=self.estimator,
                                                    X=temp_features.iloc[:, feature_now],
                                                    y=label,
                                                    scoring=self.eval_metric,
                                                    cv=self.cv))
                if self.greater_is_better and (score_now - score_best > self.threshold):
                    score_best = score_now
                    feature_best = feature
                    update = True
                elif (not self.greater_is_better) and (score_best - score_now > self.threshold):
                    score_best = score_now
                    feature_best = feature
                    update = True
            if not update:
                continue
            else:
                feature_selected.append(feature_best)
                feature_not_selected.remove(feature_best)
        self.out_features = temp_features.iloc[:, feature_selected]
        return self.out_features

    def save(self, output_path: str = None):
        if not os.path.isdir(output_path):
            os.makedirs(output_path)

        pca_output_path = os.path.join(output_path, 'pca/')
        # 如何使用到了PCA，需要保存PCA的模型，PCA是特征合并算法，并不能还原原来的特征名称
        if self.ff_pca:
            pca_output_path = os.path.join(output_path, 'pca/')
            self.ff_pca.save(pca_output_path)
        else:
            if os.path.isdir(pca_output_path):
                shutil.rmtree(pca_output_path)

        if self.out_features is not None:
            feature_output_path = os.path.join(output_path, 'feature_filter.csv')
            ff_data = pd.DataFrame(list(self.out_features), columns=['feature_name'])
            ff_data.to_csv(feature_output_path)
        else:
            raise ValueError(
                'out_features empty error, please assign a value to the class variable out_features in the feature_filter function!')
