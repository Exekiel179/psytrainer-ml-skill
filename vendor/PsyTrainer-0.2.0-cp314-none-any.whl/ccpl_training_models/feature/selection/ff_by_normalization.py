#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: hn
@Date: 2023/04/20
@Version: 1.0.0
@Description: 标准化
'''

import os
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

from ..ff_base import FFBase


class FFByNor(FFBase):
    """
    Feature filter by Pca,

    """
    params = {}

    def __init__(self, params: dict):
        """
        实例初始化过程，保存传入的参数。

        Args:
            params (dict, optional): 详见父类说明.
        """
        print(type(self).__name__, ' __init__ params:', params)
        self.set_params(params)

    def set_params(self, params: dict):
        super().set_params(params)

    def feature_filter(self, features: pd.DataFrame):
        """
        标准化特征。具体定义见父类说明。

        Args:
            features (DataFrame, optional): 遵循基类的参数类型.

        Returns:
            DataFrame: 返回值类型，也是类包pandas的DataFrame类型。
        """
        print('feature_filter: FDRWithNor...')
        print('params:', self.params)
        nor_num = features.values
        values = nor_num.astype('float32')  # 定义数据类型
        tool = MinMaxScaler(feature_range=(0, 1))
        ff_x = tool.fit_transform(values)  # ndarray
        print('type before ff_x:', type(ff_x))
        self.out_features = pd.DataFrame(ff_x)
        print('type after ff_x:', type(self.out_features))
        print(self.out_features)
        return self.out_features
    
    def save(self, output_path: str = None):
        if not os.path.isdir(output_path):
            os.makedirs(output_path)
        
        if self.out_features is not None:
            feature_output_path = os.path.join(output_path, 'feature_filter.csv')
            ff_data = pd.DataFrame(list(self.out_features), columns=['feature_name'])
            ff_data.to_csv(feature_output_path)
        else:
            raise ValueError('out_features empty error, please assign a value to the class variable out_features in the feature_filter function!')
        