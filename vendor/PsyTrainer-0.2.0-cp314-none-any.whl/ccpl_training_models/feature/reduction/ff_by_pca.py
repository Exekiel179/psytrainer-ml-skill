#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: PCA特征降维算法
'''

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from ..ff_base import FFBase


class FFByPca(FFBase):
    """
    Feature filter by Pca,
    
    """
    params = {'pca_num': 30}
    pac = None
    
    def __init__(self, params: dict):
        """
        实例初始化过程，保存传入的参数。

        Args:
            params (dict, optional): 详见父类说明.
        """
        print(type(self).__name__, ' __init__ params:', params)
        self.set_params(params)
    
    def set_params(self, params: dict):
        super().set_params(params)
    
    def feature_filter(self, features: pd.DataFrame):
        """
        PCA 特征筛选过程。具体定义见父类说明。

        Args:
            features (DataFrame, optional): 遵循基类的参数类型.

        Returns:
            DataFrame: 返回值类型，也是类包pandas的DataFrame类型。
        """
        print('feature_filter: FDRWithPca...')
        print('params:', self.params)
        pca_num = self.params['pca_num']
        sample_num = features.shape[0]
        n = np.min([pca_num, sample_num])
        print('n: ', n)
        self.pca = PCA(n_components=n)
        # pca_model = self.pca.fit(features)
        # ff_x = pca_model.transform(features)
        ff_x = self.pca.fit_transform(features)
        print('type before ff_x:', type(ff_x))
        self.out_features = pd.DataFrame(ff_x)
        print('type after ff_x:', type(self.out_features))
        print(self.out_features)
        return self.out_features
    
    def save(self, output_path: str = None):
        if not os.path.isdir(output_path):
            os.makedirs(output_path)
            
        if self.out_features is not None:
            feature_output_path = os.path.join(output_path, 'feature_filter.csv')
            print('out_features', list(self.out_features))
            ff_data = pd.DataFrame(list(self.out_features), columns=['feature_name'])
            ff_data.to_csv(feature_output_path)
        else:
            raise ValueError('out_features empty error, please assign a value to the class variable out_features in the feature_filter function!')
        
        pca_output_path = os.path.join(output_path, 'pca.m')
        joblib.dump(self.pca, pca_output_path)
        