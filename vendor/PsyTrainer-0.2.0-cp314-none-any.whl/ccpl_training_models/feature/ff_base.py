#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from abc import ABCMeta, abstractmethod

import pandas as pd


class FFBase(metaclass=ABCMeta):
    """
    FF: feature filter(特征筛选). 包括特征降维和特征选择两部分。 

    Raises:
        AttributeError: __init__函数，在子类中需要实现，否则报错AttributeError。
        AttributeError: feature_filter函数，在子类中需要实现，否则报错AttributeError。
    """
    params = {}
    features: pd.DataFrame = None

    @abstractmethod
    def __init__(self, params=None):
        """
        子类初始化函数。

        Args:
            params (dict, optional): 参数以字典形式传入，在子类中实现参数的保存。
            如果不需要参数，可忽略params的使用。

        Raises:
            AttributeError: 子类必须实现这个方法，否则抛出AttributeError。
        """
        print('FFBase: __init__()')
        raise AttributeError('子类必须实现这个方法：__init__')

    @abstractmethod
    def set_params(self, params=None):
        if params is not None and isinstance(params, dict):
            self.params = {}
            for key in params:
                self.params[key] = params[key]
        print(type(self).__name__, ' set_params:', self.params)

    @abstractmethod
    def feature_filter(self, features: pd.DataFrame):
        """
        子类实现具体的特征筛选过程，需要主要的传入参数类型。

        Args:
            features (DataFrame, optional): 需要传入类包pandas的DataFrame类型.
            
        Returns:
            DataFrame: 返回值类型，也是类包pandas的DataFrame类型。

        Raises:
            AttributeError: 子类必须实现这个方法，否则抛出AttributeError。
        """
        print('FFBase: feature_filter()')
        raise AttributeError('子类必须实现这个方法：feature_filter')

    @abstractmethod
    def save(self, output_path: str = None):
        print(type(self).__name__, ' save()')
        raise AttributeError('子类必须实现这个方法：save')
