#!/usr/bin/python3
# -*- coding: UTF-8 -*-

import os
import sys

code_path = os.path.abspath(os.path.join(sys.path[0], ".."))
if code_path not in sys.path:
    sys.path.append(code_path)
    