#!/usr/bin/python3
# -*- coding: UTF-8 -*-

import os
import sys
from enum import Enum
import numpy as np
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel

"""
步态视频模型训练的参数类，不同的训练模型单独创建一个枚举的类，
保存该模型下使用的训练参数。提供给apps模块下的接口使用

"""


class RandomForestParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 20],
        criterion=['squared_error', 'absolute_error', 'poisson'],
        max_depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        max_features=['sqrt', 'log2'],
        oob_score=[True, False],
        bootstrap=[True, False],
        min_samples_split=[1, 2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
    )


class SVRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=['linear', 'poly', 'rbf', 'sigmoid'],
        gamma=['scale', 'auto'],
        C=np.linspace(0.01, 2, 100)
    )


class GPRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=[None, DotProduct(), WhiteKernel(), DotProduct() + WhiteKernel()],
        alpha=[1e-8, 1e-9, 1e-10, 1e-11, 1e-12],
        n_restarts_optimizer=[0, 1, 2],
        normalize_y=[False, True]
    )


class LRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        fit_intercept=[True, False],
        positive=[True, False]
    )
