#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from enum import Enum
import numpy as np

"""
面部视频模型训练的参数类，不同的训练模型单独创建一个枚举的类，
保存该模型下使用的训练参数。提供给apps模块下的借口使用

"""


class RandomForestParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 20],
        criterion=['squared_error', 'absolute_error', 'poisson'],
        max_depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        max_features=['sqrt', 'log2'],
        oob_score=[True, False],
        bootstrap=[True, False],
        min_samples_split=[1, 2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
    )


class KNeighborsRegressorParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_neighbors=list(range(2, 15)) + [20, 30, 40, 50],
        weights=['uniform', 'distance'],
        algorithm=['auto', 'ball_tree', 'kd_tree', 'brute'],
        p=[1, 2, 3]
    )
