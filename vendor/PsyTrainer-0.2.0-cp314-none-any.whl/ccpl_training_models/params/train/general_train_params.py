#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/06/01
@Version: 1.0.0
@Description: 定义模型训练的参数
'''

from enum import Enum

import numpy as np
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel


class CatBoostParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        iterations=[2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 20, 50, 100],
        learning_rate=np.linspace(0.01, 2, 80),
        depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        loss_function=['MAE', 'MAPE', 'Poisson', 'RMSE']
    )


class SVCParams(Enum):
    classification = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=['linear', 'poly', 'rbf', 'sigmoid'],
        gamma=['scale', 'auto'],
        C=[0.01, 0.1, 1, 10, 100, 1000]
    )


class SVRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=['linear', 'poly', 'rbf', 'sigmoid'],
        gamma=['scale', 'auto'],
        C=np.linspace(0.01, 2, 100)
    )


class RandomForestParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 20],
        criterion=['squared_error', 'absolute_error', 'poisson'],
        max_depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        max_features=['sqrt', 'log2'],
        oob_score=[True, False],
        bootstrap=[True, False],
        min_samples_split=[1, 2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
    )
    classification = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 20],
        criterion=['gini', 'entropy', 'log_loss'],
        max_depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        max_features=['sqrt', 'log2', None],
        min_samples_split=[1, 2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
    )


class XGBoostParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        max_depth=range(1, 20),
        learning_rate=np.linspace(0.01, 3, 200),
        n_estimators=list(range(2, 15)) + [20, 30, 40, 50]
    )
    classification = dict(
        max_depth=range(1, 15),
        learning_rate=np.linspace(0, 1, 200),
        n_estimators=list(range(2, 15)) + list(range(20, 100, 20)) + list(range(100, 1001, 100)),
        colsample_bytree=np.linspace(0, 1, 200),
        subsample=np.linspace(0, 1, 200),
        gamma=list(range(0, 1000, 25))
    )


class LGBMParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        boosting_type=['gbdt', 'goss'],
        num_leaves=[2, 3, 4, 5, 6, 7, 8, 10, 15, 31, 50, 100],
        max_depth=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        learning_rate=np.linspace(0.01, 2, 50),
        n_estimators=list(range(2, 15)) + [20, 30, 40, 50]
    )
    classification = dict(
        boosting_type=['gbdt', 'goss', 'rf', 'dart'],
        num_leaves=list(range(2, 15)) + list(range(20, 200, 20)),
        max_depth=list(range(1, 31)),
        learning_rate=np.logspace(np.log10(0.01), np.log10(1), 50),
        n_estimators=list(range(2, 15)) + [20, 30, 40, 50],
        feature_fraction=np.linspace(0, 1, 50)
    )


class GPRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=[None, DotProduct(), WhiteKernel(), DotProduct() + WhiteKernel()],
        alpha=[1e-8, 1e-9, 1e-10, 1e-11, 1e-12],
        n_restarts_optimizer=[0, 1, 2],
        normalize_y=[False, True]
    )


class LRParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        fit_intercept=[True, False],
        positive=[True, False]
    )
    classification = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        C=[0.01, 0.1, 1, 10, 100, 1000],
        penalty=['l1', 'l2', 'elasticnet', None],
        fit_intercept=[True, False],
        solver=['newton-cg', 'lbfgs', 'liblinear', 'sag', 'saga'],
        multi_class=['auto', 'ovr', 'multinomial'],
        max_iter=[50, 100, 200, 300],
        class_weight=['balanced', None]
    )


class ExtraTreeParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[50, 200, 500, 800, 1000, 1500],
        criterion=['squared_error', 'absolute_error', 'poisson'],
        max_depth=[2, 3, 4, 5, 6, 7, 8, 9, 10],
        max_features=['sqrt', 'log2'],
        oob_score=[True, False],
        bootstrap=[True, False],
        min_samples_split=[1, 2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
    )


class AdaBoostParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=list(range(2, 15)) + [20, 30, 40, 50],
        learning_rate=np.linspace(0.01, 2, 50),
        loss=['linear', 'square', 'exponential'],
    )
    classification = dict(
        n_estimators=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 20, 30, 40, 50],
        learning_rate=[(0.97 + x / 100) for x in range(0, 8)]
    )


class GradientBoostingParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=[50, 100, 200, 500, 800, 1000, 1500],
        learning_rate=np.linspace(0.01, 1, 30),
        loss=['squared_error', 'absolute_error', 'huber', 'quantile'],
        criterion=['friedman_mse', 'squared_error']
        # random_state=np.linspace(20, 50, 6)
    )


class BaggingParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_estimators=list(range(2, 15)) + [20, 30, 40, 50],
        max_samples=[0.05, 0.1, 0.2, 0.5],
        max_features=[0.05, 0.1, 0.2, 0.5],
        bootstrap=[True, False]
    )


class KNeighborsParams(Enum):
    regression = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        n_neighbors=list(range(2, 15)) + [20, 30, 40, 50],
        weights=['uniform', 'distance'],
        algorithm=['auto', 'ball_tree', 'kd_tree', 'brute'],
        p=[1, 2, 3]
    )
    classification = dict(
        n_neighbors=[5, 7, 9, 11, 13, 15],
        weights=['uniform', 'distance'],
        algorithm=['auto', 'ball_tree', 'kd_tree', 'brute'],
        metric=['minkowski', 'euclidean', 'manhattan']
    )


class NaiveBayesParams(Enum):
    classification = dict(
        var_smoothing=np.logspace(0, -9, num=100)
    )


class DecisionTreesParams(Enum):
    classification = dict(
        max_depth=[3, 5, 7, 9, None],
        min_samples_split=[2, 3, 4, 5, 6],
        min_samples_leaf=[1, 2, 3, 4, 5, 6],
        max_features=['sqrt', 'log2'],
        criterion=['gini', 'entropy'],
        splitter=['best', 'random']
    )
