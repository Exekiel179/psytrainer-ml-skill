import os
import shutil
from typing import Union

import pandas as pd

from ccpl_training_models.feature.ff_factory import FFFactory
from ccpl_training_models.model.model_factory import ModelFactory
from ccpl_training_models.model.model_training import ModelTraining
from ccpl_training_models.sampler.sampler_factory import SamplerFactory
from ccpl_training_models.util.file_utils import from_jsonfile, to_jsonfile
from ccpl_training_models.util.scoring_utils import SCORINGS_DEFAULT, SCORINGS_CLASSIFIER


class Trainer:
    __train_type = "general"
    __is_need_clean = False
    __is_use_model_params = True
    __cross_validation_times = 5
    __custom_scoring = "default"
    __pca_num = 30
    __ff_tags = None
    __model_tags = "regression"
    __resample_tags = None

    def __init__(self, train_type: str = "general"):
        if train_type is not None:
            self.__train_type = train_type
        self.__model_factory = ModelFactory(self.__train_type)

    def set_cv_times(self, cv_times: int):
        self.__cross_validation_times = cv_times

    def set_pca_num(self, pca_num: int):
        self.__pca_num = pca_num

    def set_scoring(self, scoring: list):
        self.__custom_scoring = scoring

    def set_is_need_clean(self, is_need_clean: bool):
        self.__is_need_clean = is_need_clean

    def set_is_use_model_params(self, is_use_model_params: bool):
        self.__is_use_model_params = is_use_model_params

    def set_resample_tags(self, resample_tags: Union[None, str, list]):
        self.__resample_tags = resample_tags

    def set_ff_tags(self, ff_tags: Union[None, str, list]):
        self.__ff_tags = ff_tags

    def set_model_tags(self, model_tags: Union[str, list]):
        self.__model_tags = model_tags

    def set_base_config(self, **kwargs):
        if "cv_times" in kwargs:
            self.set_cv_times(kwargs["cv_times"])

        if "pca_num" in kwargs:
            self.set_pca_num(kwargs["pca_num"])

        if "scoring" in kwargs:
            self.set_scoring(kwargs["scoring"])

        if "is_need_clean" in kwargs:
            self.set_is_need_clean(kwargs["is_need_clean"])

        if "is_use_model_params" in kwargs:
            self.set_is_use_model_params(kwargs["is_use_model_params"])

        if "resample_tags" in kwargs:
            self.set_resample_tags(kwargs["resample_tags"])

        if "ff_tags" in kwargs:
            self.set_ff_tags(kwargs["ff_tags"])

        if "model_tags" in kwargs:
            self.set_model_tags(kwargs["model_tags"])

    def __get_scoring_by_names(self, scoring: list) -> list:
        if isinstance(self.__custom_scoring, list):
            return [scoring_instance for scoring_instance in scoring if scoring_instance.name in self.__custom_scoring]

        return scoring

    def __get_classification_scoring(self):
        return self.__get_scoring_by_names(SCORINGS_CLASSIFIER)

    def __get_regression_scoring(self):
        return self.__get_scoring_by_names(SCORINGS_DEFAULT)

    def get_scoring(self, model_type):
        # 在测试集上评估交叉验证模型性能的策略
        if model_type == 0:
            return self.__get_classification_scoring()

        return self.__get_regression_scoring()

    def get_ff_params(self, features: pd.DataFrame, labels: pd.Series, ff_tag, scoring):
        if ff_tag is None:
            return None

        if self.__ff_tags == "all_ff":
            return dict(
                cv=self.__cross_validation_times,
                scorings=scoring,
                pca_num=min(self.__pca_num, features.shape[1]),
                threshold=0.0,
                estimator=None,
                eval_metric='neg_root_mean_squared_error',
                greater_is_better=True,
                label=labels
            )

        feature_filter_params = FFFactory.get_ff_params(ff_tag)
        if feature_filter_params is not None:
            if "cv" in feature_filter_params:
                feature_filter_params['cv'] = self.__cross_validation_times

            if "pca_num" in feature_filter_params:
                feature_filter_params['pca_num'] = self.__pca_num

            if "label" in feature_filter_params:
                feature_filter_params['label'] = labels

        return feature_filter_params

    def get_ff_tags(self):
        if self.__ff_tags is None:
            return [None]

        if self.__ff_tags == "all_ff":
            return FFFactory.get_all_ff_tags()

        if isinstance(self.__ff_tags, list):
            return self.__ff_tags
        else:
            raise Exception('ff_tags error: please check ff_tags setting.')

    def get_model_tags(self):
        if self.__model_tags == "classification":
            return self.__model_factory.get_all_model_tags(model_type=0)

        if self.__model_tags == "regression":
            return self.__model_factory.get_all_model_tags(model_type=1)

        if isinstance(self.__model_tags, list):
            return self.__model_tags
        else:
            raise Exception('model_tags error: please check model_tags setting.')

    def get_resample_tags(self):
        if self.__resample_tags is None:
            return [None]

        if self.__resample_tags == "all_resample":
            return SamplerFactory().get_all_sampler_tags()

        if isinstance(self.__resample_tags, list):
            return self.__resample_tags
        else:
            raise Exception('resample_tags error: please check resample_tags setting.')

    def build_model(
        self,
        model_type: int,
        ff_tag,
        model_tag,
        features: pd.DataFrame,
        labels: pd.Series,
        output_path: str = None,
    ):
        scoring = self.get_scoring(model_type)
        ff_params = self.get_ff_params(features, labels, ff_tag, scoring)
        print(f"ff_params: {ff_params}")

        training_params = self.__model_factory.get_model_params(model_tag)

        model_training = ModelTraining(
            ff_tag,
            ff_params,
            model_tag,
            {"training_params": training_params if self.__is_use_model_params else None},
            self.__cross_validation_times,
            scoring,
            output_path=output_path,
            train_type=self.__train_type
        )

        return model_training.run(features, labels)

    @staticmethod
    def save_result(result, tag, running_tags, best_result_path, result_list_path, done_file_path):
        result_list = from_jsonfile(result_list_path) if os.path.exists(result_list_path) else []

        result["tag"] = tag
        result_list.append(result)
        result_list.sort(key=lambda x: x['best_score'], reverse=True)
        best_result = result_list[0].copy()

        running_tags.append(tag)
        # 保存运行状态
        if running_tags is not None and len(running_tags) > 0:
            tags_data = pd.DataFrame(running_tags, columns=['tag'])
            tags_data.to_csv(done_file_path)

        to_jsonfile(best_result, best_result_path)
        to_jsonfile(result_list, result_list_path)

        return best_result, result_list

    def run(self, features: pd.DataFrame, labels: pd.Series, output_path: str = None):
        """
            函数拥有中断后，下次接着运行的功能。
        """
        print('training_models...')
        if not output_path:
            raise Exception('output error: please input a output path.')

        if self.__is_need_clean and os.path.isdir(output_path):
            # 清除之前的运行记录
            shutil.rmtree(output_path)

        os.makedirs(output_path, exist_ok=True)

        best_result_path = os.path.join(output_path, 'best_result.json')
        result_list_path = os.path.join(output_path, 'result_list.json')

        result_list = from_jsonfile(result_list_path) if os.path.exists(result_list_path) else []
        best_result = from_jsonfile(best_result_path) if os.path.exists(best_result_path) else None

        print('from_jsonfile best_result:', best_result)
        print('from_jsonfile result_list:', result_list)

        # 运行中断保存在文件中运行过的tag
        done_file_path = os.path.join(output_path, 'done_tag.csv')
        done_tags = list(pd.read_csv(done_file_path).loc[:, 'tag']) if os.path.exists(done_file_path) else []
        print('done_tags: ', done_tags)

        # 正在运行的tag
        running_tags = []
        for ff_tag in self.get_ff_tags():
            for model_tag in self.get_model_tags():
                # 是否中断后，继续训练
                tag = f'{ff_tag}#{model_tag}'
                if tag in done_tags:
                    # 判断tag是否已经存在，存在就不再训练，继续下一次训练
                    running_tags.append(tag)
                    continue

                model_type = self.__model_factory.get_model_type(model_tag)
                if model_type is None:
                    raise Exception('model type error: please check model type.')

                if model_type == 0:
                    for resample_tag in self.get_resample_tags():
                        c_output_path = output_path
                        if resample_tag is not None:
                            print(f"resample_tag: {resample_tag}")
                            features, labels = SamplerFactory().resample(features, labels, resample_tag)
                            tag = f'{ff_tag}#{model_tag}#{resample_tag}'
                            c_output_path = os.path.join(c_output_path, resample_tag)

                        if tag in done_tags:
                            running_tags.append(tag)
                            continue

                        result, _, _ = self.build_model(model_type, ff_tag, model_tag, features, labels, c_output_path)
                        best_result, result_list = self.save_result(
                            result, tag, running_tags, best_result_path, result_list_path, done_file_path)
                else:
                    result, _, _ = self.build_model(model_type, ff_tag, model_tag, features, labels, output_path)
                    best_result, result_list = self.save_result(
                        result, tag, running_tags, best_result_path, result_list_path, done_file_path)

        return best_result, result_list
