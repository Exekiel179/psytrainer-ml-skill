#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 模型训练类
'''

import os
import shutil
import pandas as pd

from ccpl_training_models.config.project_config import DEBUG
from ccpl_training_models.feature.ff_factory import FFFactory
from .model_factory import ModelFactory


class ModelTraining(object):
    cross_validation_times = 5
    ff_factory = None
    model_factory = None
    scoring: dict = {}
    refit: str = None
    output_path: str = None
    ff_tag: str = None
    model_tag: str = None

    def __init__(self, feature_filter_tag: str, feature_filter_params: dict, model_tag: str, model_params: dict,
                 cross_validation_times=5, scoring=[], **kwargs):
        """
        创建模型训练实例。
        
        Parameters:
            feature_filter_tag(str): 需要选择的特征筛选类的标签“tag”
            feature_filter_params(dict): 特征筛选类需要的参数，字典形式传参
            model_tag(str): 需要用于训练的算法模型
            model_params(dict): 算法模型使用的参数
        """
        print('ModelTraining init...', model_params)
        self.ff_tag = feature_filter_tag
        self.model_tag = model_tag
        self.cross_validation_times = cross_validation_times

        train_type = kwargs['train_type'] if 'train_type' in kwargs else "general"
        self.model_factory = ModelFactory(train_type).create_model(model_tag, model_params)

        if feature_filter_params is not None and "estimator" in feature_filter_params:
            feature_filter_params['estimator'] = self.model_factory.model

        if feature_filter_tag is not None:
            self.ff_factory = FFFactory().create_ff(feature_filter_tag, feature_filter_params)

        if scoring is not None and len(scoring) > 0:
            self.scoring = {}
            for i, key in enumerate(scoring):
                if i == 0:
                    print(i, 'key:', key)
                    self.refit = key.name
                self.scoring[key.name] = key.value
        self.output_path = kwargs['output_path']

    def run(self, features: pd.DataFrame, labels: pd.Series):
        """
        模型训练。
        
        Parameters:
            features(pandas.DataFrame): 传入特征列表，类型为pandas的DataFrame
            labels(pandas.Series): 传入标签列表，类型为pandas的Series
        """
        if self.ff_factory is not None:
            X = self.ff_factory.feature_filter(features)
        else:
            X = features
        Y = labels

        # ====== 测试代码 上线删除  =================================================
        if DEBUG:  # 减少模型训练参数，避免调试的时候训练时间太长
            self.model_factory.set_training_params(getattr(self.model_factory, 'training_params_test'))
        # =========================================================================

        print('ModelTraining run...', getattr(self.model_factory, 'params'))
        best_params_info, grid_result, custom_info = self.model_factory.training(X, Y, self.cross_validation_times,
                                                                                 self.scoring, self.refit)
        best_params_info['ff_and_model'] = '%s#%s' % (self.ff_tag, self.model_tag)
        if self.output_path:
            # 保存筛选后的特征的名字和训练后的模型
            dir_path = os.path.join(self.output_path,
                                    '%s&%s/' % (type(self.ff_factory).__name__, type(self.model_factory).__name__))
            # 先清空原始的记录
            if os.path.isdir(dir_path):
                shutil.rmtree(dir_path)
            os.makedirs(dir_path)
            print('type X: ', list(X))
            print('X: ', X)

            # 保存筛选后的特征名
            # 如果这里是none的话说明未进行特征筛选，就无需保存筛选后特征
            if self.ff_factory is not None:
                self.ff_factory.save(output_path=dir_path)
            # 保存训练后的模型
            self.model_factory.save(output_path=dir_path)

        return best_params_info, grid_result, custom_info
