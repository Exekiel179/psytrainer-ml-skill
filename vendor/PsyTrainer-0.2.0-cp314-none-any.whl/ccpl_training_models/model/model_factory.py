#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 模型工厂类，需要将具体的模型实例类注册在这个文件中。如“from .regression.model_random_forest_regressor import ModelRandomForestRegressor”
'''

from ccpl_training_models.config.project_config import DEBUG
import ccpl_training_models.params.train.general_train_params as general_train_params
import ccpl_training_models.params.train.audio.default as audio_train_params
import ccpl_training_models.params.train.face.default as face_train_params
import ccpl_training_models.params.train.gait.default as gait_train_params
import ccpl_training_models.params.train.text.default as text_train_params

# classification models
from .classification.model_ada_boost_classifier import ModelAdaBoostClassifier
from .classification.model_decision_trees_classifier import ModelDecisionTreesClassifier
from .classification.model_kneighbors_classifier import ModelKNeighborsClassifier
from .classification.model_lgbm_classifier import ModelLGBMClassifier
from .classification.model_lr_classifier import ModelLRClassifier
from .classification.model_naive_bayes_classifier import ModelNaiveBayesClassifier
from .classification.model_random_forest_classifier import ModelRandomForestClassifier
from .classification.model_svc_classifier import ModelSVCClassifier
from .classification.model_xgboost_classifier import ModelXGBoostClassifier

# regression models
from .regression.model_ada_boost_regressor import ModelAdaBoostRegressor
from .regression.model_bagging_regressor import ModelBaggingRegressor
from .regression.model_cat_boost_regressor import ModelCatBoostRegressor
from .regression.model_extratree_regressor import ModelExtraTreeRegressor
from .regression.model_gpr_regressor import ModelGPRRegressor
from .regression.model_gradient_boosting_regressor import ModelGradientBoostingRegressor
from .regression.model_kneighbors_regressor import ModelKNeighborsRegressor
from .regression.model_lgbm_regressor import ModelLGBMRegressor
from .regression.model_lr_regressor import ModelLRRegressor
from .regression.model_random_forest_regressor import ModelRandomForestRegressor
from .regression.model_svr_regressor import ModelSVRRegressor
from .regression.model_xgboost_regressor import ModelXGBoostRegressor


TRAIN_PARAMS_SETTINGS = {
    "general": general_train_params,
    "audio": audio_train_params,
    "face": face_train_params,
    "gait": gait_train_params,
    "text": text_train_params,
}


class ModelFactory(object):
    
    def __init__(self, train_type: str = "general"):
        print(f"train_type: {train_type}")
        self.train_type = train_type
        self.classification_model_training_params = self.set_classification_model_training_params()
        self.regression_model_training_params = self.set_regression_model_training_params()
        self.model_types = self.set_model_types()

    def get_training_params(self, model_name: str, model_type: str = "regression"):
        assert self.train_type in TRAIN_PARAMS_SETTINGS.keys(), f"Invalid train type: {self.train_type}"

        train_params = getattr(TRAIN_PARAMS_SETTINGS[self.train_type], model_name, None)

        if train_params and hasattr(train_params, model_type):
            param_dict = getattr(train_params, model_type)
        else:
            general_param_class = getattr(general_train_params, model_name)
            param_dict = getattr(general_param_class, model_type)

        assert param_dict is not None, f"Model parameters for '{model_name}' and '{model_type}' are not found."

        return param_dict.value

    def set_model_types(self):
        if DEBUG:
            return {
                0: ['ModelRandomForestRegressor'],
                1: ['ModelRandomForestClassifier']
            }
        else:
            return {
                0: list(self.classification_model_training_params.keys()),
                1: list(self.regression_model_training_params.keys())
            }

    def set_regression_model_training_params(self):
        return {
            'ModelAdaBoostRegressor': self.get_training_params("AdaBoostParams"),
            'ModelBaggingRegressor': self.get_training_params("BaggingParams"),
            'ModelCatBoostRegressor': self.get_training_params("CatBoostParams"),
            'ModelExtraTreeRegressor': self.get_training_params("ExtraTreeParams"),
            'ModelGPRRegressor': self.get_training_params("GPRParams"),
            'ModelGradientBoostingRegressor': self.get_training_params("GradientBoostingParams"),
            'ModelKNeighborsRegressor': self.get_training_params("KNeighborsParams"),
            'ModelLGBMRegressor': self.get_training_params("LGBMParams"),
            'ModelLRRegressor': self.get_training_params("LRParams"),
            'ModelRandomForestRegressor': self.get_training_params("RandomForestParams"),
            'ModelSVRRegressor': self.get_training_params("SVRParams"),
            'ModelXGBoostRegressor': self.get_training_params("XGBoostParams")
        }

    def set_classification_model_training_params(self):
        return {
            'ModelAdaBoostClassifier': self.get_training_params("AdaBoostParams", "classification"),
            'ModelDecisionTreesClassifier': self.get_training_params("DecisionTreesParams", "classification"),
            'ModelKNeighborsClassifier': self.get_training_params("KNeighborsParams", "classification"),
            'ModelLGBMClassifier': self.get_training_params("LGBMParams", "classification"),
            'ModelLRClassifier': self.get_training_params("LRParams", "classification"),
            'ModelNaiveBayesClassifier': self.get_training_params("NaiveBayesParams", "classification"),
            'ModelRandomForestClassifier': self.get_training_params("RandomForestParams", "classification"),
            'ModelSVCClassifier': self.get_training_params("SVCParams", "classification"),
            'ModelXGBoostClassifier': self.get_training_params("XGBoostParams", "classification")
        }

    def get_all_model_tags(self, model_type: int = 1):
        """
        获取所有模型的tag。

        Args:
            model_type (int): 值解释（0: 分类算法， 1: 回归算法）
            
        Return: 根据model_type返回对应的tag列表。
        
        """
        if model_type in self.model_types.keys():
            return self.model_types[model_type]
        else:
            return None

    def get_model_params(self, tag):
        if tag in self.classification_model_training_params.keys():
            return self.classification_model_training_params[tag]
        elif tag in self.regression_model_training_params.keys():
            return self.regression_model_training_params[tag]
        else:
            return None

    def get_model_type(self, tag):
        for key, value in self.model_types.items():
            if tag in value:
                return key
        return None

    @staticmethod
    def create_model(name: str, params: dict):
        return eval(name)(params)
