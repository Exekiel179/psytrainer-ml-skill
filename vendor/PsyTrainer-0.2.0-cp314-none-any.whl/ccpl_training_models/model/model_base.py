#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 算法模型虚拟基类，所有继承该基类的子类都需要实现__init__()和training()方法，
              否则会报错
'''

from abc import ABCMeta, abstractmethod
import os
import joblib
import pandas as pd
from sklearn.model_selection import GridSearchCV

from ccpl_training_models.util.file_utils import to_jsonfile


class ModelBase(metaclass=ABCMeta):
    """
    算法虚拟基类. 包括分类和回归两类算法。 

    Raises:
        AttributeError: __init__函数，在子类中需要实现，否则报错AttributeError。
        AttributeError: training函数，在子类中需要实现，否则报错AttributeError。
    """

    params = {}
    training_params = {}
    model = None
    features: pd.DataFrame = None
    label: pd.Series = None
    best_result = None
    grid: GridSearchCV = None

    @abstractmethod
    def __init__(self, params=None):
        """
        子类初始化函数。

        Args:
            params (dict, optional): 参数以字典形式传入，在子类中实现参数的保存。
            具体参数与模型需要的训练参数相关，参数已列表的方式传入，用于网格搜索GridSearchCV。

        Raises:
            AttributeError: 子类必须实现这个方法，否则抛出AttributeError。
        """
        print('ModelBase: __init__():', params)
        raise AttributeError('子类必须实现这个方法：__init__')

    @abstractmethod
    def set_params(self, params=None):
        if params is not None and isinstance(params, dict):
            self.params = {}
            for key in params:
                value = params[key]
                self.params[key] = value
                if 'training_params' == key and self.params['training_params'] is not None:
                    self.training_params = {}
                    for training_key in value:
                        self.training_params[training_key] = value[training_key]
        print(type(self).__name__, ' set_params:', self.params)

    def set_training_params(self, training_params):
        self.training_params = training_params

    @abstractmethod
    def training(self, features: pd.DataFrame, label: pd.Series, cross_validation_times=5, scoring=[]):
        """
        子类实现具体的训练过程，可使用GridSearchCV寻找最优参数，需要主要的传入参数类型。

        Args:
            features (DataFrame, optional): 需要传入类包pandas的DataFrame类型.
            label (Series, optional): 需要传入类包pandas的Series类型.
            
        Returns:
            (Dict, GridSearchCV, Dict): 返回值为元组类型，第一个参数为Dict字典类型输出最优参数得分及相关信息。
            第二个参数为GridSearchCV训练后的结果信息，包括具体的所有参数的训练数据。
            第三个参数为自定义字典类型，可根据需要自定义返回信息，字典类型。

        Raises:
            AttributeError: 子类必须实现这个方法，否则抛出AttributeError。
        """
        raise AttributeError('子类必须实现这个方法：training')

    @abstractmethod
    def save(self, output_path: str = None):
        print(type(self).__name__, ' save()')
        if self.features is None:
            raise ValueError(
                'features empty error, please assign a value to the class variable features in the training function!')
        if self.label is None:
            raise ValueError('label empty error, please assign a value to the class variable label in the training function!')
        if self.grid is None:
            raise ValueError('grid empty error, please assign a value to the class variable grid in the training function!')

        if not os.path.isdir(output_path):
            os.makedirs(output_path)

        # 使用网格搜索后的最佳参数，用完整的数据在训练一遍，导出模型
        self.grid.best_estimator_.fit(self.features, self.label)
        if not os.path.isdir(output_path):
            os.makedirs(output_path)
        model_output_path = os.path.join(output_path, 'model.pkl')
        joblib.dump(self.grid.best_estimator_, model_output_path)

        to_jsonfile(self.best_result, os.path.join(output_path, 'model_best_result.json'))
