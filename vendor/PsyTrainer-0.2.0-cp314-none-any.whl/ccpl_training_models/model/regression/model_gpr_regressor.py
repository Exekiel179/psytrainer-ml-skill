#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: wyy
@Date: 2023/04
@Version: 1.0.0
@Description: GaussianProcessRegressor
'''

import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel

from ..model_base import ModelBase
from ccpl_training_models.util.data_utils import get_grid_best_params


class ModelGPRRegressor(ModelBase):
    # 测试参数
    training_params_test = dict(
        # 参数后面必须是一个列表, 列表内的值可以根据自己的程序选择
        kernel=[None, DotProduct(), WhiteKernel(), DotProduct() + WhiteKernel()],
        alpha=[1e-10],
        n_restarts_optimizer=[1],
        normalize_y=[False, True]
    )

    # training_params = GPRParams.regression

    def __init__(self, params: dict):
        print(type(self).__name__, ' __init__ params:', params)
        self.model = GaussianProcessRegressor()
        self.set_params(params)

    def set_params(self, params: dict):
        super().set_params(params)

    def training(self, features: pd.DataFrame, label: pd.Series, cross_validation_times=5, scoring={}, refit=None):
        print(type(self).__name__, ' training...')
        print('params:', self.params)
        # 保存需要的数据
        self.features = features
        self.label = label

        cv_split = KFold(n_splits=cross_validation_times, shuffle=True)
        self.grid = GridSearchCV(self.model, self.training_params, cv=cv_split, scoring=scoring, refit=refit)
        self.grid.fit(features, label)

        self.best_result = get_grid_best_params(self.grid, cross_validation_times, scoring, refit)
        custom_info = {}

        return self.best_result, self.grid, custom_info

    def save(self, output_path: str = None):
        super().save(output_path)
