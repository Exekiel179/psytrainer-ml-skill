#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: hn
@Date: 2023/05/06
@Version: 1.0.0
@Description: k近邻回归
'''

import pandas as pd
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import GridSearchCV, KFold

from ..model_base import ModelBase
from ccpl_training_models.util.data_utils import get_grid_best_params


class ModelKNeighborsRegressor(ModelBase):
    # 测试参数
    training_params_test = dict(
        # 参数以列表的形式传递，用于后续的GridSearchCV的运行找出最优解
        n_neighbors=[5],
        weights=['uniform'],
        algorithm=['auto'],
        p=[2]
    )

    def __init__(self, params: dict):
        print(type(self).__name__, ' __init__ params:', params)
        self.model = KNeighborsRegressor()
        self.set_params(params)

    def set_params(self, params: dict):
        super().set_params(params)

    def training(self, features: pd.DataFrame, label: pd.Series, cross_validation_times=5, scoring={}, refit=None):
        print(type(self).__name__, ' training...')
        print('params:', self.params)
        # 保存需要的数据
        self.features = features
        self.label = label
        
        cv_split = KFold(n_splits=cross_validation_times, shuffle=True)
        self.grid = GridSearchCV(self.model, self.training_params, cv=cv_split, scoring=scoring, refit=refit)
        self.grid.fit(features, label)

        self.best_result = get_grid_best_params(self.grid, cross_validation_times, scoring, refit)
        custom_info = {}

        return self.best_result, self.grid, custom_info
    
    def save(self, output_path: str = None):
        super().save(output_path)
