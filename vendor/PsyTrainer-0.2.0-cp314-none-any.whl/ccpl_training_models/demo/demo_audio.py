#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 示例程序，详细说明了两种代码使用方法。
'''

import os
import sys
import numpy as np

import __init__
import pandas as pd
from model.model_training import ModelTraining

from util.scoring_utils import SCORING

from apps.audio.interface import audio_training_by_freg_and_kneighborsregressor, audio_training_by_freg_and_randomforestregressor

if __name__ == '__main__':
    print('processing start...')
    print(sys.path)
    cur_path = os.path.dirname(__file__)
    print('cur_path: ', cur_path)
    path_feature = os.path.join(cur_path, 'testdata/audio/test_data_20s-join.csv')
    X = pd.read_csv(path_feature)

    path_label = os.path.join(cur_path, 'testdata/audio/label_GAD-7.csv')
    Y = pd.read_csv(path_label)
    y_one_label = None
    for y_label in Y.columns:
        # if y_label != 'a': #由于读入数据为str类型，因此在此暂时注释掉
        #     continue
        #     print(y_label)
        # print(y_label)
        y_one_label = Y.loc[:, y_label]
        # 创建训练类

        # 创建训练类


    # model_training = ModelTraining('FFByFregression',
    #                                {'label': y_one_label},
    #                                'ModelRandomForestRegressor',
    #                                dict(n_estimators=np.linspace(1, 15, 15, dtype=int)),
    #                                5,
    #                                [SCORING.pearson_r, SCORING.mae, SCORING.mse])
    # best_params_info, _, _ = model_training.run(X, y_one_label)



    # 面向对象的训练方法使用
    # best_params_info, _, _ = audio_training_by_freg_and_randomforestregressor(X, y_one_label)
    best_params_info, _, _ = audio_training_by_freg_and_kneighborsregressor(X, y_one_label)
    print(best_params_info)
    # print(grid.cv_results_)
