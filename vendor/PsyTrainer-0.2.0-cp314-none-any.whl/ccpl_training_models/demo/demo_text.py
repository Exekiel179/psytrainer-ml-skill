#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: HanNuo
@Date: 2023/04/10
@Version: 1.0.0
@Description: 示例程序，详细说明了两种代码使用方法。
'''

import os
import sys
import numpy as np

import __init__
import pandas as pd
from apps.face.interface import face_training_by_pca_and_catboostregressor, face_training_by_pca_and_lgbm, face_training_by_pca_and_randomforestregressor, face_training_by_pca_and_svr, face_training_by_pca_and_xgboost
from apps.general_interface import training_with_all_ffs_and_regression_models
from model.model_training import ModelTraining
from util.scoring_utils import SCORING
from apps.text.interface import gamingbehave_training_by_stepforward_and_randomforestregressor, text_training_by_normal_and_extratreeregressor,text_training_by_extratreeregressor,text_training_by_normal_and_adaboostregressor,text_training_by_adaboostregressor,\
text_training_by_normal_and_gradientboostingregressor,text_training_by_gradientboostingregressor,text_training_by_normal_and_baggingregressor,text_training_by_baggingregressor,\
text_training_by_normal_and_kneighborsregressor,text_training_by_kneighborsregressor


if __name__ == '__main__':
    print('processing start...')
    print(sys.path)
    cur_path = os.path.dirname(__file__)
    print('cur_path: ', cur_path)
    path_feature = os.path.join(cur_path, 'testdata/text/text_feature_test.csv')
    X = pd.read_csv(path_feature, index_col=0)
    
    path_label = os.path.join(cur_path, 'testdata/text/text_label_test.csv')
    Y = pd.read_csv(path_label, index_col=0)
    y_one_label = None
    for y_label in Y.columns:
        # if y_label != 'a': #由于读入数据为str类型，因此在此暂时注释掉
        #     continue
        #     print(y_label)
        # print(y_label)
        y_one_label = Y.loc[:, y_label]

    # 创建训练类
    # model_training = ModelTraining('FFByNor',
    #                                None,
    #                                'ModelKNeighborsRegressor',
    #                                dict(n_neighbors=np.linspace(1, 15, 15, dtype=int)),
    #                                5,
    #                                [SCORING.pearson_r, SCORING.mae, SCORING.mse])
    # best_params_info, grid, custom_info = model_training.run(X, y_one_label)
        
        
        
    
    # 面向对象的训练方法使用
    # best_params_info, _, _ = text_training_by_normal_and_kneighborsregressor(X, y_one_label)
    # best_params_info, _, _ = text_training_by_normal_and_baggingregressor(X, y_one_label)
    # best_params_info, _, _ = text_training_by_normal_and_gradientboostingregressor(X, y_one_label) # 运行不进行
    # best_params_info, _, _ = text_training_by_normal_and_adaboostregressor(X, y_one_label)
    # best_params_info, _, _ = text_training_by_normal_and_extratreeregressor(X, y_one_label)
    # best_params_info, _, _ = gamingbehave_training_by_stepforward_and_randomforestregressor(X, y_one_label)
    best_params_info, _, _ = training_with_all_ffs_and_regression_models(X, y_one_label, cv_times=5, pca_num=30)
    print(best_params_info)
    # print(grid.cv_results_)
        