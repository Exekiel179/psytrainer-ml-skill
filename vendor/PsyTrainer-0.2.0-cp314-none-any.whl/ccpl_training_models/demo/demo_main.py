#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 示例程序，详细说明了两种代码使用方法。
'''

import os
import sys
import numpy as np
import sklearn

import __init__
import pandas as pd
from apps.face.interface import face_training_by_pca_and_randomforestregressor
from apps.general_interface import training_with_all_ffs_and_classification_models, \
    training_with_all_ffs_and_regression_models, training_with_default_params_of_classification_models, \
    training_with_default_params_of_regression_models, training_with_ff_and_model
from apps.text.interface import gamingbehave_training_by_stepforward_and_randomforestregressor
from model.model_training import ModelTraining
from params.train.face.default import RandomForestParams
from util.scoring_utils import SCORING, SCORINGS_DEFAULT

if __name__ == '__main__':
    print('processing start...')
    print(sys.path)
    cur_path = os.path.dirname(__file__)
    print('cur_path: ', cur_path)
    output_path = os.path.join(cur_path, 'output/')
    path_feature = os.path.join(cur_path, 'testdata/face/20220828_feature_1125.csv')
    X = pd.read_csv(path_feature, index_col=0)

    path_label = os.path.join(cur_path, 'testdata/face/label_index.csv')
    Y = pd.read_csv(path_label, index_col=0)
    y_one_label = None
    for y_label in Y.columns:
        if y_label != 'a':
            continue
        print(y_label)
        y_one_label = Y.loc[:, y_label]

    # 创建训练类
    # model_training = ModelTraining('FFByPca',
    #                                {'pca_num': 30},
    #                                'ModelRandomForestRegressor',
    #                                dict(n_estimators=np.linspace(1, 15, 15, dtype=int)),
    #                                5,
    #                                [SCORING.pearson_r, SCORING.mae, SCORING.mse])
    # best_params_info, grid, custom_info = model_training.run(X, y_one_label)

    # 面向对象的训练方法使用
    # best_params_info, _, _ = face_training_by_pca_and_randomforestregressor(X, y_one_label, output_path=output_path)
    # best_params_info, _, _ = face_training_by_randomforestregressor(X, y_one_label)
    # best_params_info, _, _ = face_training_by_pca_and_catboostregressor(X, y_one_label)     # 不能运行
    # best_params_info, _, _ = face_training_by_catboostregressor(X, y_one_label)     # 不能运行
    # best_params_info, _, _ = face_training_by_pca_and_svr(X, y_one_label)       # 不能运行
    # best_params_info, _, _ = face_training_by_svr(X, y_one_label)       # 不能运行
    # best_params_info, _, _ = face_training_by_pca_and_xgboost(X, y_one_label)
    # best_params_info, _, _ = face_training_by_xgboost(X, y_one_label)
    # best_params_info, _, _ = face_training_by_pca_and_lgbm(X, y_one_label)
    # best_params_info, _, _ = face_training_by_lgbm(X, y_one_label)

    # best_params_info, _, _ = gamingbehave_training_by_stepforward_and_randomforestregressor(X, y_one_label, output_path=output_path)
    # names = sklearn.metrics.get_scorer_names()
    # print('names: ', names)

    # 全部模型运行
    # best, _, _ = training_with_ff_and_model(X, y_one_label,
    #                                         'FFByPca',
    #                                         {'pca_num': 30},
    #                                         'ModelRandomForestRegressor',
    #                                         {'training_params': RandomForestParams.regression.value},
    #                                         5,
    #                                         SCORINGS_DEFAULT,
    #                                         output_path = output_path)

    # 全模型运行
    # best, results = training_with_all_ffs_and_regression_models(X, y_one_label,
    #                                                  cv_times=5,
    #                                                  pca_num=30,
    #                                                  output_path=output_path,
    #                                                  is_need_clean=True)
    # best, results = training_with_default_params_of_regression_models(X, y_one_label,
    #                                                                   'FFByPca',
    #                                                                   {'pca_num': 30},
    #                                                                   5,
    #                                                                   SCORINGS_DEFAULT,
    #                                                                   output_path = output_path,
    #                                                                   is_use_model_param = True,
    #                                                                   is_need_clean = True)
    # best, results = training_with_default_params_of_regression_models(X, y_one_label,
    #                                                                   None,
    #                                                                   None,
    #                                                                   5,
    #                                                                   SCORINGS_DEFAULT,
    #                                                                   output_path = output_path,
    #                                                                   is_need_clean=False)

    # best, results = training_with_all_ffs_and_classification_models(X, y_one_label,
    #                                                  cv_times=5,
    #                                                  pca_num=30,
    #                                                  output_path=output_path,
    #                                                  is_need_clean=True)
    best, results = training_with_default_params_of_classification_models(X, y_one_label,
                                                                          None,
                                                                          None,
                                                                          5,
                                                                          SCORINGS_DEFAULT,
                                                                          output_path=output_path,
                                                                          is_need_clean=False)
    print(results)
    print(best)
    # print(grid.cv_results_)