#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 示例程序，详细说明了两种代码使用方法。
'''

import os
import sys
import numpy as np

import __init__
import pandas as pd
from apps.face import interface
from model.model_training import ModelTraining
from util.scoring_utils import SCORING


if __name__ == '__main__':
    print('processing start...')
    print(sys.path)
    cur_path = os.path.dirname(__file__)
    print('cur_path: ', cur_path)
    path_feature = os.path.join(cur_path, 'testdata/face/20220828_feature_1125.csv')
    X = pd.read_csv(path_feature, index_col=0)
    
    path_label = os.path.join(cur_path, 'testdata/face/label_index.csv')
    Y = pd.read_csv(path_label, index_col=0)
    y_one_label = None
    for y_label in Y.columns:
        if y_label != 'a':
            continue
        print(y_label)
        y_one_label = Y.loc[:, y_label]

    # 创建训练类
    # model_training = ModelTraining('FFByPca', 
    #                                {'pca_num': 30}, 
    #                                'ModelRandomForestRegressor', 
    #                                dict(n_estimators=np.linspace(1, 15, 15, dtype=int)),
    #                                5,
    #                                [SCORING.pearson_r, SCORING.mae, SCORING.mse])
    # best_params_info, grid, custom_info = model_training.run(X, y_one_label)
        
        
        
    
    # 面向对象的训练方法使用
    # best_params_info, _, _ = interface.face_training_by_pca_and_randomforestregressor(X, y_one_label)
    # best_params_info, _, _ = interface.face_training_by_randomforestregressor(X, y_one_label)
    best_params_info, _, _ = interface.face_training_by_pca_and_catboostregressor(X, y_one_label)     # 不能运行
    # best_params_info, _, _ = interface.face_training_by_catboostregressor(X, y_one_label)     # 不能运行
    # best_params_info, _, _ = interface.face_training_by_pca_and_svr(X, y_one_label)       # 不能运行
    # best_params_info, _, _ = interface.face_training_by_svr(X, y_one_label)       # 不能运行
    # best_params_info, _, _ = interface.face_training_by_pca_and_xgboost(X, y_one_label)
    # best_params_info, _, _ = interface.face_training_by_xgboost(X, y_one_label)
    # best_params_info, _, _ = interface.face_training_by_pca_and_lgbm(X, y_one_label)
    # best_params_info, _, _ = interface.face_training_by_lgbm(X, y_one_label)
    print(best_params_info)
    # print(grid.cv_results_)
        