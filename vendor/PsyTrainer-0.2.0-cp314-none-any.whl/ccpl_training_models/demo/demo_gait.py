#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: wyy
@Date: 2023/04
@Version: 1.0.0
@Description: 示例程序，步态代码使用方法。
'''

import os
import sys
import numpy as np

import __init__
import pandas as pd
from apps.gait.interface import  gait_training_by_pca_and_randomforestregressor, gait_training_by_pca_and_svr, gait_training_by_pca_and_gpr, gait_training_by_pca_and_lr
from model.model_training import ModelTraining
from util.scoring_utils import SCORING


if __name__ == '__main__':
    print('processing start...')
    print(sys.path)
    cur_path = os.path.dirname(__file__)
    print('cur_path: ', cur_path)
    path_feature = os.path.join(cur_path, 'testdata/gait/gait_time_feature.txt')
    X = np.loadtxt(path_feature)
    X = pd.DataFrame(X)
    
    path_label = os.path.join(cur_path, 'testdata/gait/gait_label.txt')
    Y = np.loadtxt(path_label)
    # Y = np.loadtxt(path_label,dtype=str)
    Y = pd.DataFrame(Y)


    #确定label使用哪一列
    label_num = 1
    y_one_label = Y.iloc[:, label_num]
    # y_one_label = np.array(y_one_label, dtype=float)

    # 创建训练类
    # model_training = ModelTraining('FFByPca',
    #                                {'pca_num': 30},
    #                                'ModelRandomForestRegressor',
    #                                dict(n_estimators=np.linspace(1, 15, 15, dtype=int)),
    #                                5,
    #                                [SCORING.pearson_r, SCORING.mae, SCORING.mse])
    # best_params_info, grid, custom_info = model_training.run(X, y_one_label)
        
        
        
    
    # 面向对象的训练方法使用
    # best_params_info, grid, custom_info = gait_training_by_pca_and_randomforestregressor(X, y_one_label)
    best_params_info, grid, custom_info = gait_training_by_pca_and_svr(X, y_one_label)   #训练不能进行
    # best_params_info, grid, custom_info = gait_training_by_pca_and_lr(X, y_one_label)
    # best_params_info, grid, custom_info = gait_training_by_pca_and_gpr(X, y_one_label)

    print(best_params_info)
    # print(grid.cv_results_)
        