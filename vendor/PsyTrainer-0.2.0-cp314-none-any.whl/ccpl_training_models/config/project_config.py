#!/usr/bin/python3
# -*- coding: UTF-8 -*-
'''
@Author: CaiLei
@Date: 2023/04/10
@Version: 1.0.0
@Description: 配置文件，上线时DEBUG需要设置为False
'''

DEBUG = False
STEPFORWARD_MAX_FEATURE_NUMBER = 100
